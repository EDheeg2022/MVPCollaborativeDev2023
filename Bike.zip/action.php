<?php
class DBConnection {
    private $_dbHostname;
    private $_dbName;
    private $_dbUsername;
    private $_dbPassword;
    private $_con;

    public function __construct($hostname, $dbName, $username, $password) {
        $this->_dbHostname = $hostname;
        $this->_dbName = $dbName;
        $this->_dbUsername = $username;
        $this->_dbPassword = $password;

        try {
            $this->_con = new PDO("mysql:host=$this->_dbHostname;dbname=$this->_dbName", $this->_dbUsername, $this->_dbPassword);
            $this->_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function returnConnection() {
        return $this->_con;
    }
}

class Cart {
    protected $db;
    private $_sku;

    public function setSKU($sku) {
        $this->_sku = $sku;
    }

    public function __construct() {
        $hostname = "localhost";
        $dbName = "wlvbagnz_db";
        $username = "wlvbagnz_admin";
        $password = "kOolio99-";
        $this->db = new DBConnection($hostname, $dbName, $username, $password);
        $this->db = $this->db->returnConnection();
    }

    public function getAllProduct() {
        try {
            $sql = "SELECT * FROM products";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }

    public function getProduct() {
        try {
            $sql = "SELECT * FROM products WHERE sku=:sku";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':sku', $this->_sku);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }
}


$servername = "localhost";
$database = "wlvbagnz_db";
$username = "wlvbagnz_admin";
$password = "kOolio99-";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
	//die("Connection failed: " . mysqli_connect_error());
}



if (isset($_GET['login'])) {
	session_start();
	$user = $_POST['username'];
	if ($stmt = $conn->prepare('SELECT id, password, name FROM customers WHERE username = ?')) {
		$stmt->bind_param('s', $_POST['username']);
		$stmt->execute();
		$stmt->store_result();
		if ($stmt->num_rows > 0) {
			$stmt->bind_result($id, $password, $name);
			$stmt->fetch();
			if ($_POST['password'] === $password) {
				session_regenerate_id();
				$_SESSION['loggedin'] = true;
				$_SESSION['name'] = $_POST['username'];
				$username = $_POST['username'];
				$_SESSION['pass'] = $_POST['password'];
				$_SESSION['id'] = $id;
				$_SESSION['fullname'] = $name;
				echo json_encode(
					array(
						'status' => 'ok'
					)
				);
			} else {
				echo json_encode(
					array(
						'status' => 'notok'
					)
				);
			}
		} else {
			echo json_encode(
				array(
					'status' => 'notok'
				)
			);
		}
		$stmt->close();
	}
}

if (isset($_GET['logout'])) {
	session_start();
	session_destroy();
	header('location:product.php');
	exit;
}

if (isset($_GET['deletecustomer'])) {
	$userid = $_POST['customer'];
	$query = mysqli_query($conn, "DELETE FROM customers WHERE id=$userid");
	if ($query) {
		echo json_encode(
			array(
				'status' => 'ok'
			)
		);
	} else {
		echo json_encode(
			array(
				'status' => 'notok'
			)
		);
	}
}

if (isset($_GET['addcustomer'])) {
	if (!empty($_POST['username'] and $_POST['password'] and $_POST['level'] and $_POST['name'] and $_POST['email'] and $_POST['phone'])) {
		$username = $_POST['username'];
		$password = $_POST['password'];
		$name = $_POST['name'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$level = $_POST['level'];
		$query = mysqli_query($conn, "INSERT INTO customers (username, password, name, email, phone, level) VALUES ('$username','$password','$name','$email','$phone','$level')");
		if ($query) {
			echo json_encode(array('status' => 'ok'));
		} else {
			echo json_encode(array('status' => 'notok'));
		}
	} else {
		echo json_encode(array('status' => 'notok'));
	}
}


if (isset($_GET['addproduct'])) {
	if (!empty($_POST['name'] and $_POST['sku'] and $_POST['price'] and $_FILES['imagefile'])) {
		$name = $_POST['name'];
		$sku = $_POST['sku'];
		$price = $_POST['price'];
		$file = $_FILES['imagefile'];
		$names = $file['name'];
		$path = "images/" . basename($names);
		move_uploaded_file($file['tmp_name'], $path);
		$query = mysqli_query($conn, "INSERT INTO products (name, sku, image, price) VALUES ('$name','$sku','$path','$price')");
		if ($query) {
			echo json_encode(array('status' => 'ok'));
		} else {
			echo json_encode(array('status' => 'notok'));
		}
	} else {
		echo json_encode(array('status' => 'notok'));
	}
}


if (isset($_GET['deleteproduct'])) {
	$userid = $_POST['product'];
	$query = mysqli_query($conn, "DELETE FROM products WHERE id=$userid");
	if ($query) {
		echo json_encode(
			array(
				'status' => 'ok'
			)
		);
	} else {
		echo json_encode(
			array(
				'status' => 'notok'
			)
		);
	}
}

if (isset($_GET['editproduct'])) {
	if (!empty($_POST['id'] and $_POST['name'] and $_POST['sku'] and $_POST['price'])) {
		$prodid = $_POST['id'];
		$name = $_POST['name'];
		$sku = $_POST['sku'];
		$price = $_POST['price'];
		if (!empty($_FILES['imagefile'])) {
			$file = $_FILES['imagefile'];
			$names = $file['name'];
			$path = "images/" . basename($names);
			move_uploaded_file($file['tmp_name'], $path);
		}
		$query = mysqli_query($conn, "UPDATE products SET name='$name', sku='$sku', image='$path', price='$price' WHERE id=$prodid");
		if ($query) {
			echo json_encode(array('status' => 'ok'));
		} else {
			echo json_encode(array('status' => 'notok'));
		}
	}
}

if (isset($_GET['add'])) {
	session_start();
	$json = array();
	$cart = new Cart();
	$cart->setSKU($_POST["sku"]);
	$productByCode = $cart->getProduct();
	if (!empty($_POST["quantity"])) {
		$itemArray = array(
			$productByCode["sku"] =>
			array(
				'name' => $productByCode["name"],
				'sku' => $productByCode["sku"],
				'quantity' => $_POST["quantity"],
				'price' => $productByCode["price"],
				'image' => $productByCode["image"]
			)
		);
		if (!empty($_SESSION["cart_item"])) {
			if (in_array($productByCode["sku"], array_keys($_SESSION["cart_item"]))) {
				foreach ($_SESSION["cart_item"] as $k => $v) {
					if ($productByCode["sku"] == $k) {
						if (empty($_SESSION["cart_item"][$k]["quantity"])) {
							$_SESSION["cart_item"][$k]["quantity"] = 0;
						}
						$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
					}
				}
			} else {
				$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"], $itemArray);
			}
		} else {
			$_SESSION["cart_item"] = $itemArray;
		}
		$json['count'] = array_sum(array_column($_SESSION["cart_item"], 'quantity'));
	}

	header('Content-Type: application/json');
	echo json_encode($json);
}

if (isset($_GET['remove'])) {
	session_start();
	$json = array();
	$total_quantity = 0;
	$total_price = 0;
	if (!empty($_SESSION["cart_item"]) && count($_SESSION["cart_item"]) > 0) {
		if (!empty($_SESSION["cart_item"])) {
			foreach ($_SESSION["cart_item"] as $k => $v) {
				if ($_POST["remove"] == $k) {
					if ($_SESSION["cart_item"][$k]["quantity"] > 1) {
						$_SESSION["cart_item"][$k]["quantity"] = $_SESSION["cart_item"][$k]["quantity"] - 1;
						$json['quantity'] = $_SESSION["cart_item"][$k]["quantity"];
						$json['itemprice'] = number_format($_SESSION["cart_item"][$k]["quantity"] * $_SESSION["cart_item"][$k]["price"], 2);
					} else {
						unset($_SESSION["cart_item"][$k]);
					}
				}
			}
		}
		$bindHTML = '';
		foreach ($_SESSION["cart_item"] as $item) {
			$total_quantity += $item["quantity"];
			$total_price += ($item["price"] * $item["quantity"]);
		}
		$json['total_quantity'] = $total_quantity;
		$json['total_price'] = number_format($total_price, 2);
		$json['count'] = $total_quantity;
	}
	header('Content-Type: application/json');
	echo json_encode($json);
}
if (isset($_GET['addcart'])) {
	session_start();
	$json = array();
	$total_quantity = 0;
	$total_price = 0;
	if (!empty($_SESSION["cart_item"]) && count($_SESSION["cart_item"]) > 0) {
		if (!empty($_SESSION["cart_item"])) {
			foreach ($_SESSION["cart_item"] as $k => $v) {
				if ($_POST["add"] == $k) {
					if ($_SESSION["cart_item"][$k]["quantity"] > 0) {
						$_SESSION["cart_item"][$k]["quantity"] = $_SESSION["cart_item"][$k]["quantity"] + 1;
						$json['quantity'] = $_SESSION["cart_item"][$k]["quantity"];
						$json['itemprice'] = number_format($_SESSION["cart_item"][$k]["quantity"] * $_SESSION["cart_item"][$k]["price"], 2);
					} else {
						unset($_SESSION["cart_item"][$k]);
					}
				}
			}
		}
		$bindHTML = '';
		foreach ($_SESSION["cart_item"] as $item) {
			$total_quantity += $item["quantity"];
			$total_price += ($item["price"] * $item["quantity"]);
		}
		$json['total_quantity'] = $total_quantity;
		$json['total_price'] = number_format($total_price, 2);
		$json['count'] = $total_quantity;
	}
	header('Content-Type: application/json');
	echo json_encode($json);
}

