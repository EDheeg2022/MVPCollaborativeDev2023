<?php
session_start();
class DBConnection {
    private $_dbHostname;
    private $_dbName;
    private $_dbUsername;
    private $_dbPassword;
    private $_con;

    public function __construct($hostname, $dbName, $username, $password) {
        $this->_dbHostname = $hostname;
        $this->_dbName = $dbName;
        $this->_dbUsername = $username;
        $this->_dbPassword = $password;

        try {
            $this->_con = new PDO("mysql:host=$this->_dbHostname;dbname=$this->_dbName", $this->_dbUsername, $this->_dbPassword);
            $this->_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function returnConnection() {
        return $this->_con;
    }
}

class Cart {
    protected $db;
    private $_sku;

    public function setSKU($sku) {
        $this->_sku = $sku;
    }

    public function __construct() {
        $hostname = "localhost";
        $dbName = "wlvbagnz_db";
        $username = "wlvbagnz_admin";
        $password = "kOolio99-";
        $this->db = new DBConnection($hostname, $dbName, $username, $password);
        $this->db = $this->db->returnConnection();
    }

    public function getAllProduct() {
        try {
            $sql = "SELECT * FROM products";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }

    public function getProduct() {
        try {
            $sql = "SELECT * FROM products WHERE sku=:sku";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':sku', $this->_sku);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }
}


$servername = "localhost";
$database = "wlvbagnz_db";
$username = "wlvbagnz_admin";
$password = "kOolio99-";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
	//die("Connection failed: " . mysqli_connect_error());
}


if (!isset($_SESSION['loggedin'])) {
    exit(header('location: index.php'));
}

$id = $_SESSION['id'];
$query = mysqli_query($conn, "SELECT * FROM customers WHERE id=$id");
if ($query) {
    $arr = mysqli_fetch_array($query, MYSQLI_ASSOC);
    $level = $arr['level'];
}

if ($level !== "admin") {
    exit(header('location: product.php'));
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>WlvBike4rent</title>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet"
        type="text/css">
    <link href="assets/style.css" rel="stylesheet">
    <link href="assets/toastr.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
</head>

<body>
    <section class="showcase" id="accountsectionid">
        <div class="container">
            <div class="pb-2 mt-4 mb-2 border-bottom">
                <h2>WlvBike4rent - Accounts

                    <a style="float: right;margin-left:10px" href="product.php" class="btn btn-primary text-right">
                        Shopping
                    </a>

                    <a style="float: right;margin-left:10px" data-toggle="modal" data-target="#addingcustomer"
                        class="btn btn-info text-right">
                        Add New Account
                    </a>

                    <a style="float: right;" onclick="product();" class="btn btn-success text-right">
                        Products
                    </a>

                </h2>
            </div>
            <div class="row">
                <div class="col-xl-3 col-md-3 col-sm-3 col-6">
                    <input type="text" id="MySearchID" onkeyup="MySearchTable()"
                        class="form-control search-input container-fluid border-0" placeholder="Search username..."
                        aria-label="Search username..." />
                    <i class="bx bx-x bx-sm search-toggler cursor-pointer"></i>
                </div>
                <div class="col-xl-3 col-md-3 col-sm-3 col-6">
                    <select name="filterdropdownID" id="filterdropdownID" class="form-select"
                        aria-controls="DataTables_Table_0" class="form-select">
                        <option value="All" selected>All</option>
                        <option value="admin">Admin</option>
                        <option value="customer">Customer</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div id="shopping-cart">
                    <table class="tbl-cart" id="myTable" cellpadding="10" cellspacing="1">
                        <thead>
                            <tr>
                                <th>UserID</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Full Name</th>
                                <th>Email Address</th>
                                <th>Phone Number</th>
                                <th>Admin</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="render-cart-data">
                            <?php
                            $query = mysqli_query($conn, "SELECT * from customers");
                            if ($query) {
                                if (mysqli_num_rows($query) >= 1) {
                                    $array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
                                }
                            }
                            if (!empty($array)) {
                                foreach ($array as $value) {
                            ?>
                            <tr id="<?php echo $value["id"]; ?>">
                                <td>
                                    <?php echo $value['id']; ?>
                                </td>
                                <td>
                                    <?php echo $value['username']; ?>
                                </td>
                                <td>
                                    <?php echo $value['password']; ?>
                                </td>
                                <td>
                                    <?php echo $value['name']; ?>
                                </td>
                                <td>
                                    <?php echo $value['email']; ?>
                                </td>
                                <td>
                                    <?php echo $value['phone']; ?>
                                </td>
                                <td>
                                    <?php echo $value['level']; ?>
                                </td>
                                <td>


                                    <a data-customer="<?php echo $value["id"]; ?>" id="deletecustomerbtn"
                                        class="text-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                </td>
                            </tr>

                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>



        <div class="modal fade" id="addingcustomer" tabindex="-1" role="dialog" aria-labelledby="addingcustomer"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Create Account
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="addcustomerform">
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Username</label>
                                <input type="text" name="username" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter username">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Password</label>
                                <input type="password" name="password" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter password">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                                <input type="text" name="name" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Full Name">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Email</label>
                                <input type="email" name="email" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Email">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Phone Number</label>
                                <input type="tel" name="phone" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Phone Number">
                            </div>

                            <div class="bd-example">
                                <select class="form-select" name="level" required aria-label="Default select example">
                                    <option value="admin">Admin</option>
                                    <option value="customer">Customer</option>
                                </select>
                            </div>
                        </form>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="addcustomerformbtn"
                            data-dismiss="modal">Create</button>
                    </div>
                </div>
            </div>
        </div>
    </section>







    <section class="showcase" id="productsectionid" style="display:none;">
        <div class="container">
            <div class="pb-2 mt-4 mb-2 border-bottom">
                <h2>WlvBike4rent - Products

                    <a style="float: right;margin-left:10px" href="product.php" class="btn btn-primary text-right">
                        Shopping
                    </a>

                    <a style="float: right;margin-left:10px" data-toggle="modal" data-target="#addingproducts"
                        class="btn btn-success text-right">
                        Add New Product
                    </a>


                    <a style="float: right;" onclick="accounts();" class="btn btn-info text-right">
                        Accounts
                    </a>

                </h2>
            </div>
            <div class="row">
                <div class="col-xl-3 col-md-3 col-sm-3 col-6">
                    <input type="text" id="MySearchIDprod" onkeyup="searchproducts()"
                        class="form-control search-input container-fluid border-0" placeholder="Search Products..."
                        aria-label="Search Products..." />
                    <i class="bx bx-x bx-sm search-toggler cursor-pointer"></i>
                </div>
            </div>
            <div class="row">
                <div id="shopping-cart">
                    <table class="tbl-cart" id="mytableprod" cellpadding="10" cellspacing="1">
                        <thead>
                            <tr>
                                <th>Preview</th>
                                <th>Product Name</th>
                                <th>Product ID</th>
                                <th>Price Per Day</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="render-cart-data">
                            <?php
                            $query = mysqli_query($conn, "SELECT * from products");
                            if ($query) {
                                if (mysqli_num_rows($query) >= 1) {
                                    $array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
                                }
                            }
                            if (!empty($array)) {
                                foreach ($array as $value) {
                            ?>
                            <tr id="<?php echo $value["id"]; ?>">
                                <td><img src="<?php echo $value["image"]; ?>" class="cart-item-image" />
                                </td>
                                <td>
                                    <?php echo $value['name']; ?>
                                </td>
                                <td>
                                    <?php echo $value['sku']; ?>
                                </td>
                                <td>
                                    £
                                    <?php echo $value['price']; ?>
                                </td>
                                <td>
                                    <a data-customer="<?php echo $value["id"]; ?>" data-toggle="modal" style="margin-right:10px;"
                                        data-target="#editproduct<?php echo $value["id"]; ?>" class="text-info"><i class="fa fa-edit"
                                            aria-hidden="true"></i></a>


                                    <a data-product="<?php echo $value["id"]; ?>" id="deleteproductbtn"
                                        class="text-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                </td>
                            </tr>


                            <?php
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <?php
           $query = mysqli_query($conn, "SELECT * from products");
                            if ($query) {
                                if (mysqli_num_rows($query) >= 1) {
                                    $array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
                                }
                            }
                            if (!empty($array)) {
                                foreach ($array as $value) {
                            ?>
        <div class="modal fade" id="editproduct<?php echo $value["id"]; ?>" tabindex="-1" role="dialog" aria-labelledby="editproduct"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Edit Product
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="editproductform">

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">ID</label>
                                <input type="text" disabled name="id" value="<?php echo $value["id"]; ?>" required class="form-control"
                                    placeholder="Enter Product ID">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Product Name</label>
                                <input type="text" name="name" value="<?php echo $value["name"]; ?>" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Product Name">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Product ID</label>
                                <input type="text" name="sku" value="<?php echo $value["sku"]; ?>" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Product ID">
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="imagefile">Image</label>
                                <input type="file" name="imagefile" value="<?php echo $value["image"]; ?>"  class="form-control" id="imagefile" />
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Product Price</label>
                                <input type="tel" name="price" value="<?php echo $value["price"]; ?>" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Product Price">
                            </div>



                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="editproductbtn"
                            data-dismiss="modal">Edit</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
                                }
                            }
                            ?>






        <div class="modal fade" id="addingproducts" tabindex="-1" role="dialog" aria-labelledby="addingproducts"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Create New Product
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="addproductfrom">

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Product Name</label>
                                <input type="text" name="name" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Product Name">
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Product ID</label>
                                <input type="text" name="sku" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Product ID">
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="imagefile">Image</label>
                                <input type="file" name="imagefile" class="form-control" id="imagefile" />
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Cost Per Day</label>
                                <input type="tel" name="price" required class="form-control"
                                    id="exampleFormControlInput1" placeholder="Enter Cost Per Day">
                            </div>


                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="addproductbtn"
                            data-dismiss="modal">Create</button>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/toastr.js"></script>

    <script>


        function searchproductsas() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("MySearchIDprod");
            filter = input.value.toUpperCase();
            table = document.getElementById("mytableprod");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        function searchproducts() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("MySearchIDprod");
            filter = input.value.toUpperCase();
            table = document.getElementById("mytableprod");
            tr = table.getElementsByTagName("tr");
            for (let i = 0; i < tr.length; i++) {
                td = tr[i].cells;
                td_filter1 = td[1].innerText;
                td_filter2 = td[2].innerText;


                if (td_filter2.toUpperCase().indexOf(filter) > -1 || td_filter1.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else
                    tr[i].style.display = "none";

            }
        }

        function product() {
            document.getElementById("accountsectionid").style.display = 'none';
            document.getElementById("productsectionid").style.display = 'block';
        }


        function accounts() {
            document.getElementById("accountsectionid").style.display = 'block';
            document.getElementById("productsectionid").style.display = 'none';
        }


        function MySearchTable() {
            var drop, search, filter1, filter2, table, tr, td, i, txtValue;
            drop = document.getElementById("filterdropdownID");
            filter1 = drop.value.toUpperCase();

            search = document.getElementById("MySearchID");
            filter2 = search.value.toUpperCase();

            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");

            for (let i = 0; i < tr.length; i++) {
                td = tr[i].cells;
                td_filter1 = td[6].innerText;
                td_filter2 = td[1].innerText;
                td_filter4 = td[6].innerText;

                if (document.getElementById("filterdropdownID").value === "All") {
                    if (td_filter2.toUpperCase().indexOf(filter2) > -1) {
                        tr[i].style.display = "";
                    } else
                        tr[i].style.display = "none";
                } else

                    if (document.getElementById("filterdropdownID").value === "admin") {
                        if (td_filter4.toUpperCase().indexOf(filter1) > -1 && td_filter2.toUpperCase().indexOf(filter2) > -1) {
                            tr[i].style.display = "";
                        } else
                            tr[i].style.display = "none";
                    } else

                        if (document.getElementById("filterdropdownID").value === "customer") {
                            if (td_filter1.toUpperCase().indexOf(filter1) > -1 && td_filter2.toUpperCase().indexOf(filter2) > -1) {
                                tr[i].style.display = "";
                            } else
                                tr[i].style.display = "none";
                        }
            }
        }

        jQuery(document).on('click', '#deletecustomerbtn', function () {
            var customer = jQuery(this).data('customer');
            jQuery.ajax({
                type: 'POST',
                url: 'action.php?deletecustomer',
                data: {
                    customer: customer
                },
                dataType: 'json',
                success: function (json) {
                    jQuery("#" + customer).empty();
                    toastr["success"]("Account has been deleted!", "Success", {
                        progressBar: true,
                        closeButton: true,
                        timeOut: 3000,
                    });
                },
            });
        });



        jQuery(document).on('click', '#deleteproductbtn', function () {
            var product = jQuery(this).data('product');
            jQuery.ajax({
                type: 'POST',
                url: 'action.php?deleteproduct',
                data: {
                    product: product
                },
                dataType: 'json',
                success: function (json) {
                    jQuery("#" + product).empty();
                    toastr["success"]("Product has been deleted!", "Success", {
                        progressBar: true,
                        closeButton: true,
                        timeOut: 3000,
                    });
                },
            });
        });

        $(document).on("click", "#addcustomerformbtn", function (e) {
            e.preventDefault();
            var formData = $("#addcustomerform").submit(function (e) {
                return;
            });
            var formData = new FormData(formData[0]);
            $.ajax({
                url: 'action.php?addcustomer',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                cache: false,
                success: function (response) {


                    var parsed_data = JSON.parse(response);
                    if (parsed_data.status == 'ok') {
                        toastr["success"]("Account has been created! (Refresh Page)", "Success", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                    } else {
                        toastr["error"]("Account could not be created!", "Error", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                        return false;
                    }
                }

            });
            return false;
        });

        $(document).on("click", "#addproductbtn", function (e) {
            e.preventDefault();
            var formData = $("#addproductfrom").submit(function (e) {
                return;
            });
            var formData = new FormData(formData[0]);
            $.ajax({
                url: 'action.php?addproduct',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                cache: false,
                success: function (response) {

                    var parsed_data = JSON.parse(response);
                    if (parsed_data.status == 'ok') {
                        toastr["success"]("Product has been created! (Refresh Page)", "Success", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                    } else {
                        toastr["error"]("Product could not be created!", "Error", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                        return false;
                    }
                }

            });
            return false;
        });


        $(document).on("click", "#editproductbtn", function (e) {
            e.preventDefault();
            var formData = $("#editproductform").submit(function (e) {
                return;
            });
            var formData = new FormData(formData[0]);
            $.ajax({
                url: 'action.php?editproduct',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                cache: false,
                success: function (response) {

                    var parsed_data = JSON.parse(response);
                    if (parsed_data.status == 'ok') {
                        toastr["success"]("Product has been edited! (Refresh Page)", "Success", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                    } else {
                        toastr["error"]("Product could not be edited!", "Error", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                        return false;
                    }
                }

            });
            return false;
        });





    </script>