<?php
session_start();
class DBConnection {
  private $_dbHostname;
  private $_dbName;
  private $_dbUsername;
  private $_dbPassword;
  private $_con;

  public function __construct($hostname, $dbName, $username, $password) {
      $this->_dbHostname = $hostname;
      $this->_dbName = $dbName;
      $this->_dbUsername = $username;
      $this->_dbPassword = $password;

      try {
          $this->_con = new PDO("mysql:host=$this->_dbHostname;dbname=$this->_dbName", $this->_dbUsername, $this->_dbPassword);
          $this->_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      } catch(PDOException $e) {
          die("Connection failed: " . $e->getMessage());
      }
  }

  public function returnConnection() {
      return $this->_con;
  }
}

class Cart {
  protected $db;
  private $_sku;

  public function setSKU($sku) {
      $this->_sku = $sku;
  }

  public function __construct() {
      $hostname = "localhost";
      $dbName = "wlvbagnz_db";
      $username = "wlvbagnz_admin";
      $password = "kOolio99-";
      $this->db = new DBConnection($hostname, $dbName, $username, $password);
      $this->db = $this->db->returnConnection();
  }

  public function getAllProduct() {
      try {
          $sql = "SELECT * FROM products";
          $stmt = $this->db->prepare($sql);
          $stmt->execute();
          $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
          return $result;
      } catch (PDOException $e) {
          die("Oh noes! There's an error in the query: " . $e->getMessage());
      }
  }

  public function getProduct() {
      try {
          $sql = "SELECT * FROM products WHERE sku=:sku";
          $stmt = $this->db->prepare($sql);
          $stmt->bindParam(':sku', $this->_sku);
          $stmt->execute();
          $result = $stmt->fetch(PDO::FETCH_ASSOC);
          return $result;
      } catch (PDOException $e) {
          die("Oh noes! There's an error in the query: " . $e->getMessage());
      }
  }
}


$servername = "localhost";
$database = "wlvbagnz_db";
$username = "wlvbagnz_admin";
$password = "kOolio99-";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
//die("Connection failed: " . mysqli_connect_error());
}


if (!isset($_SESSION['loggedin'])) {
    exit(header('location: index.php'));
}

if (!empty($_SESSION["cart_item"])) {
    $count = array_sum(array_column($_SESSION["cart_item"], 'quantity'));
} else {
    $count = 0;
}

$id = $_SESSION['id'];
$query = mysqli_query($conn, "SELECT * FROM customers WHERE id=$id");
if ($query) {
    $arr = mysqli_fetch_array($query, MYSQLI_ASSOC);
    $customername = $arr['name'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>WlvBike4rent</title>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet"
        type="text/css">
    <link href="assets/style.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
</head>

<body>
    <section class="showcase">
        <div class="container">
            <div class="pb-2 mt-4 mb-2 border-bottom">
                <h2>WlvBike4rent - Cart <a style="float: right;" href="#" class="btn btn-primary text-right"> Cart <i
                            class="fa fa-shopping-cart" aria-hidden="true"></i>
                        <span class="badge badge-light" id="cart-count">
                            <?php echo $count; ?>
                        </span></a></h2>

            </div>
            <div class="row">
                <div id="shopping-cart">
                    <table class="tbl-cart" cellpadding="10" cellspacing="1">
                        <thead>
                            <tr>
                                <th style="text-align:left;">Name</th>
                                <th style="text-align:left;">Product ID</th>
                                <th style="text-align:right;" width="5%">Duration</th>
                                <th style="text-align:right;" width="10%">Cost Per Day</th>
                                <th style="text-align:right;" width="10%">Price</th>
                                <th style="text-align:center;" width="5%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="render-cart-data">
                            <?php
                            if (isset($_SESSION["cart_item"])) {
                                $total_quantity = 0;
                                $total_price = 0;
                                foreach ($_SESSION["cart_item"] as $item) {
                                    $item_price = $item["quantity"] * $item["price"];
                                    $total_quantity += $item["quantity"];
                                    $total_price += ($item["price"] * $item["quantity"]);
                            ?>
                            <tr id="<?php echo $item["sku"]; ?>">
                                <td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" />
                                    <?php echo $item["name"]; ?>
                                </td>
                                <td>
                                    <?php echo $item["sku"]; ?>
                                </td>
                                <td style="text-align:right;" id="renderquantity<?php echo $item["sku"]; ?>">
                                    <?php echo $item["quantity"]; ?> Days
                                </td>
                                <td style="text-align:right;">
                                    <?php echo "£ " . $item["price"]; ?>
                                </td>
                                <td style="text-align:right;" id="renderitemprice<?php echo $item["sku"]; ?>">
                                    <?php echo "£ " . number_format($item_price, 2); ?>
                                </td>
                                <td style="text-align:center;">
                                    <a data-remove="<?php echo $item["sku"]; ?>" style="margin-right:10px;"
                                        id="removebutton" class="text-danger"><i class="fa fa-minus"
                                            aria-hidden="true"></i></a>

                                    <a data-add="<?php echo $item["sku"]; ?>" id="addbutton" class="text-success"><i
                                            class="fa fa-plus" aria-hidden="true"></i></a>
                                </td>
                            </tr>
                            <?php

                                }
                            ?>
                            <tr>
                                <td colspan="2" align="right">Total:</td>
                                <td align="right" id="render-qty">
                                    <?php echo $total_quantity; ?> Days
                                </td>
                                <td align="right" colspan="2" id="render-total">
                                    <strong>
                                        <?php echo "£ " . number_format($total_price, 2); ?>
                                    </strong>
                                </td>
                                <td></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr id="cartempty" style="display:none;">
                                <td colspan="7">
                                    <div class="no-records">Your Cart is Empty</div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4"><a href="product.php" class="btn btn-warning"><i
                                            class="fa fa-angle-left"></i>
                                        Continue Shopping</a></td>

                                <td colspan="4"><a id="purchasebtn" class="btn btn-warning"  data-toggle="modal" data-target="#success_tic" data-backdrop="static" data-keyboard="false">
                                        Purchase <i class="fa fa-angle-right"></i> </a></td>
                            </tr>


                        </tfoot>
                    </table>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
    
    <div id="success_tic" class="modal fade" role="dialog">
  <div class="modal-dialog">

    
    <div class="modal-content">
      <a class="close" href="cart.php?clear" >&times;</a>
      <div class="page-body">
    <div class="head">  
      <h3 style="margin-top:5px;">Congratulation <?php echo $customername;?>! You've successfully rented:</h3>
      <?php foreach ($_SESSION["cart_item"] as $item) {?>
      <Br><Br>
      <span>Product: <?php echo $item["name"]; ?></span>
      <span>Duration: <?php echo $item["quantity"]; ?> Days</span>
      <?php }?>
      <br><Br>
    </div>

  <h1 style="text-align:center;"><div class="checkmark-circle">
  <div class="background"></div>
  <div class="checkmark draw"></div>
</div><h1>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
        jQuery(document).on('click', '#removebutton', function () {
            var remove = jQuery(this).data('remove');
            jQuery.ajax({
                type: 'POST',
                url: 'action.php?remove',
                data: {
                    remove: remove
                },
                dataType: 'json',
                success: function (json) {
                    if (json.total_quantity) {
                        jQuery('#cart-count').html(json.count);
                        jQuery('#render-qty').html(json.total_quantity);
                        jQuery('#render-total').html("£ " + json.total_price);
                        jQuery('#renderquantity' + remove).html(json.quantity);
                        jQuery('#renderitemprice' + remove).html("£ " + json.itemprice);
                    } else {
                        jQuery('#render-cart-data').empty();
                        jQuery('#cartempty').show();
                        jQuery('#cart-count').html(0);
                    }
                    if (!json.quantity) {
                        jQuery("#" + remove).empty();
                    }
                },
            });
        });
        jQuery(document).on('click', '#addbutton', function () {
            var add = jQuery(this).data('add');
            jQuery.ajax({
                type: 'POST',
                url: 'action.php?addcart',
                data: {
                    add: add
                },
                dataType: 'json',
                success: function (json) {
                    if (json.total_quantity) {
                        jQuery('#cart-count').html(json.count);
                        jQuery('#render-qty').html(json.total_quantity);
                        jQuery('#render-total').html("£ " + json.total_price);
                        jQuery('#renderquantity' + add).html(json.quantity);
                        jQuery('#renderitemprice' + add).html("£ " + json.itemprice);
                    }
                },
            });
        });

        jQuery(document).on('click', '#purchasebtn', function () {
            var add = jQuery(this).data('add');
            jQuery.ajax({
                type: 'POST',
                url: 'action.php?purchase',
                data: {
                    add: add
                },
                dataType: 'json',
                success: function (json) {
                    if (json.total_quantity) {
                        jQuery('#cart-count').html(json.count);
                        jQuery('#render-qty').html(json.total_quantity);
                        jQuery('#render-total').html("£ " + json.total_price);
                        jQuery('#renderquantity' + add).html(json.quantity);
                        jQuery('#renderitemprice' + add).html("£ " + json.itemprice);
                    }
                },
            });
        });
    </script>
    <style>
         #success_tic .page-body{
  max-width:300px;
  background-color:#FFFFFF;
  margin:10% auto;
}
 #success_tic .page-body .head{
  text-align:center;
}
/* #success_tic .tic{
  font-size:186px;
} */
#success_tic .close{
      opacity: 1;
    position: absolute;
    right: 0px;
    font-size: 30px;
    padding: 3px 15px;
  margin-bottom: 10px;
}
#success_tic .checkmark-circle {
  width: 150px;
  height: 150px;
  position: relative;
  display: inline-block;
  vertical-align: top;
}
.checkmark-circle .background {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: #1ab394;
  position: absolute;
}
#success_tic .checkmark-circle .checkmark {
  border-radius: 5px;
}
#success_tic .checkmark-circle .checkmark.draw:after {
  -webkit-animation-delay: 300ms;
  -moz-animation-delay: 300ms;
  animation-delay: 300ms;
  -webkit-animation-duration: 1s;
  -moz-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-timing-function: ease;
  -moz-animation-timing-function: ease;
  animation-timing-function: ease;
  -webkit-animation-name: checkmark;
  -moz-animation-name: checkmark;
  animation-name: checkmark;
  -webkit-transform: scaleX(-1) rotate(135deg);
  -moz-transform: scaleX(-1) rotate(135deg);
  -ms-transform: scaleX(-1) rotate(135deg);
  -o-transform: scaleX(-1) rotate(135deg);
  transform: scaleX(-1) rotate(135deg);
  -webkit-animation-fill-mode: forwards;
  -moz-animation-fill-mode: forwards;
  animation-fill-mode: forwards;
}
#success_tic .checkmark-circle .checkmark:after {
  opacity: 1;
  height: 75px;
  width: 37.5px;
  -webkit-transform-origin: left top;
  -moz-transform-origin: left top;
  -ms-transform-origin: left top;
  -o-transform-origin: left top;
  transform-origin: left top;
  border-right: 15px solid #fff;
  border-top: 15px solid #fff;
  border-radius: 2.5px !important;
  content: '';
  left: 35px;
  top: 80px;
  position: absolute;
}

@-webkit-keyframes checkmark {
  0% {
    height: 0;
    width: 0;
    opacity: 1;
  }
  20% {
    height: 0;
    width: 37.5px;
    opacity: 1;
  }
  40% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
  100% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
}
@-moz-keyframes checkmark {
  0% {
    height: 0;
    width: 0;
    opacity: 1;
  }
  20% {
    height: 0;
    width: 37.5px;
    opacity: 1;
  }
  40% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
  100% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
}
@keyframes checkmark {
  0% {
    height: 0;
    width: 0;
    opacity: 1;
  }
  20% {
    height: 0;
    width: 37.5px;
    opacity: 1;
  }
  40% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
  100% {
    height: 75px;
    width: 37.5px;
    opacity: 1;
  }
</style>

<?php if (isset($_GET['clear'])) { 

unset($_SESSION["cart_item"]);
 }?>