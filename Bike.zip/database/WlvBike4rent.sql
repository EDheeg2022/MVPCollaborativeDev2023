-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2019 at 02:48 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `customers` (
  `id` int(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `sku`, `image`, `price`) VALUES
(1, 'Carrera Valour Disc Mens Mountain Bike', 'PROD01', 'images/1.webp', 75.00),
(2, 'Assist Hybrid Electric Bike 2021', 'PROD02', 'images/2.webp', 125.00),
(3, 'Apollo Radar Mens Mountain Bike', 'PROD03', 'images/3.webp', 80.00),
(4, 'Boardman SLR 8.9 105 Mens Road Bike', 'PROD04', 'images/4.webp', 173.95),
(5, 'Voodoo Marasa Mens Hybrid Bike ', 'PROD05', 'images/5.webp', 99.99),
(6, 'Indi FS 1 Mens Mountain Bike', 'PROD06', 'images/6.webp', 50.00),
(7, 'Boss Stealth Mens Mountain Bike', 'PROD07', 'images/7.webp', 109.00),
(8, 'Raleigh Felix+ Crossbar Electric Hybrid Bike', 'PROD08', 'images/8.webp', 249.99);


INSERT INTO `customers` (`id`, `username`, `password`, `name`, `email`, `phone`, `level`) VALUES
(1, 'WlvBike4rent', 'admin', 'administration', 'Wolverhampton@wlv.ac.uk', '+447737926842', 'admin'),
(2, 'charliefox', 'charlie005', 'Charlie', 'charlie005@gmail.com', '+44882930492', 'customer');
--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`sku`);


  ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);


--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

ALTER TABLE `customers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
