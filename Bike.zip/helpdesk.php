<?php
session_start();
error_reporting(0);

if (!isset($_SESSION['loggedin'])) {
    exit(header('location: index.php'));
}


?>
<!DOCTYPE html>
<html>

<head>
    <title>WLVRentals - Help desk</title>
    <style>
        a {
            color: rgb(255, 255, 255);
            text-decoration: none;
            /* optional: remove underline */
        }

        .background {
            background-color: rgba(189, 189, 189, 0.514);
            padding: 20px;
        }

        body {
            font-size: 22px;
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        }

        img {
            max-width: 100%;
            height: auto;
        }
    </style>
    <div style="border-radius: 10px; background-color:rgb(21, 124, 219); width: 100px; height: 50px; position: absolute; bottom: 90%; left: 71%; transform: translate(50%, -50%); text-align: center; line-height: 50px; color: white;"> <a href="product.php">Home</a></div>
    <div style="border-radius: 10px; background-color:rgb(207, 10, 10); width: 100px; height: 50px; position: absolute; bottom: 90%; left: 83%; transform: translate(50%, -50%); text-align: center; line-height: 50px; color: white;"><a href="action.php?logout">Sign Out</a></div>
    <div class="background"></div>
    </body>
    <div class="background"></div>
    <h1>WLVRentals - Help Desk </h1>
    <p>We here at WLVRentals take great pride in our work and our customers and we are always here to help them with any problems with our service.</p>
    <p>If you have had any issue with our service here is a list of commonly asked questions and answers, if you need help with something specific you may contact our helpdesk via email at WLVRentals@gmail.com or on mobile at +44 7457 080754 </p>
    <img src="bike.jpg" alt="bike">

<body>
    <h2>Commonly asked questions</h2>
    <h3>Q: How long does my rental last?</h3>
    <p>A: Our bike rentals last for a period relative to the package you have chosen to pay for, you can view the available packages on the bookings page where you can see how long a rental lasts for.</p>
    <h3>Q:What happens if i lose or break the bike </h3>
    <p>A: If any of our rentals are damaged or lost a fine will be charged to pay for the loss or damages caused up to but exlusive to full price of the bike.</p>
    <h3>Q:The bike was damaged/broken when i recieved it? </h3>
    <p>A: if the bike was damaged or broken then you can contact our support to recieve your money back or a replacement bike Free of charge. </p>
    <h3>Q: i recieved the wrong bike/didnt recieve my bike?</h3>
    <p>A: depending on how busy we are, our rentals can take up to 1 work week before arriving, we apologise for this inconvenience as we do our best to provide our customers with our bikes as quickly as possible.</p>
    <p>if you recieved the wrong bike or did not recieve the bike you wanted you can contact our <a href="support.php" style="color:rgb(21, 124, 219)">support help desk</a> for help regarding the issue or call +44 7457 080754</p>
    <h3>Q: What is the quality of your bikes?</h3>
    <p>A: Our bikes have been manufactured and stress tested by premium manufacturers including but not limited to "Specialised", "Trek", "Boardman" and "Enigma" and are some of highest quality top of the line bikes that money can buy, available to customers at an affordable price.</p>
    <div class="background"> WLVRentals@gmail.com</div>
</body>
</head>

</html>