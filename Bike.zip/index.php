<?php
session_start();
error_reporting(0);

if ($_SESSION['loggedin'] == 'true') {
    exit(header('location:product.php'));
}

?>

<!doctype html>
<html lang="en">

<head>
    <title>WlvBike4rent</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href="assets/toastr.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
</head>

<body>


    <section class="ftco-section" id="loginid">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <div class="login-wrap p-4 p-md-5">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <span class="fa fa-bicycle"></span>
                        </div>
                        <h3 class="text-center mb-4">WlvBike4rent Store</h3>
                        <form id="loginformid" class="login-form">
                            <div class="form-group">
                                <input type="text" name="username" class="form-control rounded-left"
                                    placeholder="Username" required>
                            </div>
                            <div class="form-group d-flex">
                                <input type="password" name="password" class="form-control rounded-left"
                                    placeholder="Password" required>
                            </div>
                            <div class="form-group d-md-flex">
                                <div class="w-50">
                                    <label class="checkbox-wrap checkbox-primary">Remember Me
                                        <input type="checkbox" checked>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>

                                <div class="w-50">
                                    <label class="checkbox-wrap checkbox-primary">Register
                                        <input onclick="register();">
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" id="loginbtn"
                                    class="btn btn-primary rounded submit p-3 px-5">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>






    <section class="ftco-section" id="register" style="display:none;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <div class="login-wrap p-4 p-md-5">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <span class="fa fa-phone"></span>
                        </div>
                        <h3 class="text-center mb-4">WlvBike4rent Store</h3>
                        <form id="registeridform" class="login-form">

                            <input type="hidden" name="level" value="customer">


                            <div class="form-group">
                                <input type="text" name="name" class="form-control rounded-left" placeholder="Full Name"
                                    required>
                            </div>

                            <div class="form-group">
                                <input type="email" name="email" class="form-control rounded-left"
                                    placeholder="Email Address" required>
                            </div>

                            <div class="form-group">
                                <input type="tel" name="phone" class="form-control rounded-left"
                                    placeholder="Phone Number" required>
                            </div>

                            <div class="form-group">
                                <input type="text" name="username" class="form-control rounded-left"
                                    placeholder="Username" required>
                            </div>

                            <div class="form-group d-flex">
                                <input type="password" name="password" class="form-control rounded-left"
                                    placeholder="Password" required>
                            </div>

                            <div class="form-group d-md-flex">
                                <label class="checkbox-wrap checkbox-primary">Already have an account?
                                    <input onclick="login();">
                                </label>
                            </div>
                            <div class="form-group">
                                <button type="submit" id="registerbtn"
                                    class="btn btn-primary rounded submit p-3 px-5">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/toastr.js"></script>
    <script>


        function register() {
            document.getElementById("loginid").style.display = 'none';
            document.getElementById("register").style.display = 'block';
        }


        function login() {
            document.getElementById("loginid").style.display = 'block';
            document.getElementById("register").style.display = 'none';
        }
        

        $(document).on("click", "#loginbtn", function (e) {
            e.preventDefault();
            var formData = $("#loginformid").submit(function (e) {
                return;
            });
            var formData = new FormData(formData[0]);
            $.ajax({
                url: 'action.php?login',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                cache: false,
                timeout: 3000,
                success: function (response) {
                    //console.log(response);
                    
                    var parsed_data = JSON.parse(response);
                    if (parsed_data.status == 'ok') {
                        window.location.href = 'product.php?login';
                    } else {
                        toastr["error"]("Incorrect login details!", "Error", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                        return false;
                    }
                }

            });
            return false;
        });


        $(document).on("click", "#registerbtn", function (e) {
            e.preventDefault();
            var formData = $("#registeridform").submit(function (e) {
                return;
            });
            var formData = new FormData(formData[0]);
            $.ajax({
                url: 'action.php?addcustomer',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                cache: false,
                success: function (response) {
                    //console.log(response);
                    
                    var parsed_data = JSON.parse(response);
                    if (parsed_data.status == 'ok') {
                        window.location.href = 'index.php?created';
                    } else {
                        toastr["error"]("There seems to be an error, try again!", "Error", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                        return false;
                    }
                }

            });
            return false;
        });
    </script>

    <?php if (isset($_GET['created'])) { ?>
    <script>
        toastr["success"]("Account registered! Try to login now", "Success", {
            progressBar: true,
            closeButton: true,
            timeOut: 3000,
        });
    </script>
    <?php } ?>



</body>

</html>