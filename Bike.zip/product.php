<?php
session_start();
class DBConnection
{
    private $_dbHostname;
    private $_dbName;
    private $_dbUsername;
    private $_dbPassword;
    private $_con;

    public function __construct($hostname, $dbName, $username, $password)
    {
        $this->_dbHostname = $hostname;
        $this->_dbName = $dbName;
        $this->_dbUsername = $username;
        $this->_dbPassword = $password;

        try {
            $this->_con = new PDO("mysql:host=$this->_dbHostname;dbname=$this->_dbName", $this->_dbUsername, $this->_dbPassword);
            $this->_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function returnConnection()
    {
        return $this->_con;
    }
}

class Cart
{
    protected $db;
    private $_sku;

    public function setSKU($sku)
    {
        $this->_sku = $sku;
    }

    public function __construct()
    {
        $hostname = "localhost";
        $dbName = "wlvbagnz_db";
        $username = "wlvbagnz_admin";
        $password = "kOolio99-";
        $this->db = new DBConnection($hostname, $dbName, $username, $password);
        $this->db = $this->db->returnConnection();
    }

    public function getAllProduct()
    {
        try {
            $sql = "SELECT * FROM products";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }

    public function getProduct()
    {
        try {
            $sql = "SELECT * FROM products WHERE sku=:sku";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':sku', $this->_sku);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            die("Oh noes! There's an error in the query: " . $e->getMessage());
        }
    }
}


$servername = "localhost";
$database = "wlvbagnz_db";
$username = "wlvbagnz_admin";
$password = "kOolio99-";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    //die("Connection failed: " . mysqli_connect_error());
}

$cart = new Cart();
$product_array = $cart->getAllProduct();


if (!isset($_SESSION['loggedin'])) {
    exit(header('location: index.php'));
}



if (!empty($_SESSION["cart_item"])) {
    $count = array_sum(array_column($_SESSION["cart_item"], 'quantity'));
} else {
    $count = 0;
}



$id = $_SESSION['id'];
$query = mysqli_query($conn, "SELECT * FROM customers WHERE id=$id");
if ($query) {
    $arr = mysqli_fetch_array($query, MYSQLI_ASSOC);
    $level = $arr['level'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>WlvBike4rent</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="assets/style.css" rel="stylesheet">
    <link href="assets/toastr.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <Style>
        .btn {
            float: right;
            margin-left: 10px;
        }

        .text-right {
            text-align: right;
        }

        .float-right {
            float: right;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }

        .btn-info {
            background-color: #17a2b8;
            color: #fff;
        }

        .btn-danger {
            background-color: #dc3545;
            color: #fff;
        }

        .badge {
            background-color: #6c757d;
            color: #fff;
        }

        #cart-count {
            margin-left: 5px;
        }
    </style>
</head>

<body>
    <section class="showcase">
        <div class="container">
            <div class="pb-2 mt-4 mb-2 border-bottom">
                <h2>WlvBike4rent - Products

                    <a href="cart.php" class="btn btn-primary text-right float-right">
                        Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        <span class="badge badge-dark" id="cart-count"><?php echo $count; ?></span>
                    </a>

                    <?php if ($level == "admin") { ?>
                    <a href="admin.php" class="btn btn-info text-right float-right">Admin</a>
                    <?php } ?>

                    <a href="helpdesk.php" class="btn btn-warning text-right float-right">Help Desk</a>

                    <a href="support.php" class="btn btn-warning text-right float-right">Support</a>

                    <a href="action.php?logout" class="btn btn-danger text-right float-right">Logout</a>




                </h2>
            </div>




            <div class="row">
                <div class="col" id="add-item-bag" style="width:100%;"></div>
                <div id="product-grid">
                    <?php if (!empty($product_array)) {
                        foreach ($product_array as $key => $value) { ?>
                            <div class="product-item">
                                <div class="product-image">
                                    <center>
                                        <img style="height:auto;width:170px;" src="<?php echo $product_array[$key]["image"]; ?>">
                                    </center>
                                </div>
                                <div class="product-tile-footer">
                                    <div class="product-title">
                                        <?php echo $product_array[$key]["name"]; ?>
                                    </div>
                                    <div class="product-price">
                                        <?php echo "£" . $product_array[$key]["price"]; ?>/PD
                                    </div>
                                    <div class="cart-action">

                                        <input type="text" class="product-quantity" id="qty-<?php echo $product_array[$key]["id"]; ?>" name="quantity" value="1" size="2" />

                                        <button type="button" class="btnAddAction" data-itemid="<?php echo $product_array[$key]["id"]; ?>" id="product-<?php echo $product_array[$key]["id"]; ?>" data-action="action" data-sku="<?php echo $product_array[$key]["sku"]; ?>" data-proname="<?php echo $product_array[$key]["name"]; ?>">
                                            Add to Cart
                                        </button>


                                    </div>
                                </div>
                            </div>


                    <?php }
                    } ?>

    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/toastr.js"></script>
    <script type="text/javascript">
        jQuery(document).on('click', 'button.btnAddAction', function() {
            var item_id = jQuery(this).data('itemid');
            var qty = jQuery('#qty-' + item_id).val();
            var sku = jQuery(this).data('sku');
            var product_name = jQuery(this).data('proname');

            jQuery.ajax({
                type: 'POST',
                url: 'action.php?add',
                data: {
                    product_id: item_id,
                    quantity: qty,
                    sku: sku
                },
                dataType: 'json',
                beforeSend: function() {
                    jQuery('button#product-' + item_id).button('loading');
                },
                complete: function() {
                    jQuery('button#product-' + item_id).button('reset');
                },
                success: function(json) {
                    jQuery('#cart-count').html(json.count);
                    jQuery("#add-item-bag").html(
                        '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Success!</strong> You have added <strong>' +
                        'x' + qty + ' days ' +
                        product_name + '</strong> to your shopping cart!</div>');

                    toastr["success"]('You have added <strong>' +
                        'x' + qty + ' ' +
                        product_name + '</strong> to your shopping cart!', "Success", {
                            progressBar: true,
                            closeButton: true,
                            timeOut: 3000,
                        });
                },
            });
        });
    </script>

    <?php if (isset($_GET['login'])) { ?>
        <script>
            toastr["success"]("Welecome back <?php echo $_SESSION['fullname']; ?> to WlvBike4rent Store!", "Success", {
                progressBar: true,
                closeButton: true,
                timeOut: 7000,
            });
        </script>
    <?php } ?>