<?php
session_start();
error_reporting(0);

if (!isset($_SESSION['loggedin'])) {
    exit(header('location: index.php'));
}


?>
<!DOCTYPE html>
<html>
  <head>
    <title>WLVRentals - Help desk</title>
    <style>
      a {
        color: rgb(255, 255, 255);
        text-decoration: none; /* optional: remove underline */
      }
    .background {
      background-color: rgba(189, 189, 189, 0.514);
      padding: 20px;
    }  
    body {
        font-size: 22px;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        }
      img {
        max-width: 10%;
        height: auto;
      }
        .container {
			display: flex;
			flex-wrap: wrap;
            align-items: center;
		}
		.image {
			
			max-width: 50%;
			height: auto;
			margin-right: 0 auto;
		}
		.text {
			flex-grow: 50%;
			text-align: justify;
			
		}
    </style>
    <div style="border-radius: 10px; background-color:rgb(21, 124, 219); width: 100px; height: 50px; position: absolute; bottom: 90%; left: 71%; transform: translate(50%, -50%); text-align: center; line-height: 50px; color: white;" > <a href="product.php">Home</a></div>
    <div style="border-radius: 10px; background-color:rgb(207, 10, 10); width: 100px; height: 50px; position: absolute; bottom: 90%; left: 83%; transform: translate(50%, -50%); text-align: center; line-height: 50px; color: white;"><a href="action.php?logout">Sign Out</a></div>
    <div class="background"></div>
    </body>
    <div class="background"></div>
    <h1>WLVRentals - Support</h1>
    <p>Welcome to our support page, here there are a variety of resources that you can use to help you navigate our website conveniently to any of our pages.</p>
    <p>If you are seeking General assistance with a general issue, our <a href="helpdesk.php" style="color:rgb(21, 124, 219)">Helpdesk </a> contains common questions and answers from customers.</p>

 

    <body>
        <H2> Shortcuts</H2>
        <div class="container"> 
            <img src= "bike_icon.png".jpg alt="Your image description" class="bike">
            <div class="text">
                <p> <a href="product.php" style="color:rgb(21, 124, 219)"> Purchase a bike </a> </p>
            </div>
        </div>
        
        <div class="container"> 
            <img src= "cellphone.jpg".jpg alt="Your image description" class="bike">
            <div class="text">
                <p> <a href="helpdesk.php" style="color:rgb(21, 124, 219)"> Help Desk</a> </p>
            </div>
        </div>

        <div class="container"> 
            <img src= "person.jpg".jpg alt="Your image description" class="bike">
            <div class="text">
                <p> <a href="admin.php" style="color:rgb(21, 124, 219)"> Account settings </a> </p>
            </div>
        </div>

        <div class="container"> 
            <img src= "about us.png".jpg alt="Your image description" class="bike">
            <div class="text">
                <p> <a href="#" style="color:rgb(21, 124, 219)"> About us </a> </p>
            </div>
        </div>
        <p>Need any help? contact contact our helpdesk via email at WLVRentals@gmail.com or on mobile at +44 7457 080754 </p>
    </body>
    <p> </p>
    <h3> meet the team</h3>
    <p>here is a small list of our amazing members and they're the great roles they perform.</p>
    
    
    
        <div class="container"> 
            <img src= "Eliyas.jpg".jpg alt="Your image description" class="bike">
            <div class="text">
                <p> Eliyas is the team leader and the head of our project, overseeing the development of the business.</p>
            </div>
        </div>

        <div class="container"> 
          <img src= "Oscar.jpg".jpg alt="Your image description" class="bike">
          <div class="text">
              <p> Oscar Beattie: Ui Developer</p>
          </div>
      </div>

      <div class="container"> 
        <img src= "Anas.jpg".jpg alt="Your image description" class="bike">
        <div class="text">
            <p>Anas Abshir: database analyst </p>
        </div>
    </div>

    <div class="container"> 
      <img src= "Safa.jpg".jpg alt="Your image description" class="bike">
      <div class="text">
          <p>Business analyst </p>
      </div>
  </div>

    <div class="background">WLVRentals@gmail.com  +44 7457 080754</div>
  </head>
</html>